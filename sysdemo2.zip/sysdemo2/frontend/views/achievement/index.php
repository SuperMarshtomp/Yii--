<?php

use yii\helpers\Html;
use yii\grid\GridView;
use common\models\Subjects;

/* @var $this yii\web\View */
/* @var $searchModel common\models\AchievementSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = '成绩';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="achievement-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],

            //'id',
            'exam_name',
            'student_id',
            ['label'=>'学生姓名',
                'attribute' => 'student_name',
                'value' => 'student.name',
            ],
            ['label' => '班级',
                'attribute' =>'gradeclass',
                'value' => 'student.class.class_id',
            ],
            ['attribute'=>'teacher_name',
                'label'=>'学科',
                'value'=>'teacher.subject0.name',
                'filter' => Subjects::find()
                ->select(['name','id'])
                ->indexBy('id')
                ->column(),
                'contentOptions' => function ($model)
                {
                    if($model->teacher->subject==1)
                        return ['class' => 'bg-primary'];
                        else if ($model->teacher->subject==2)
                            return ['class' => 'bg-success'];
                            else if ($model->teacher->subject==3)
                                return ['class' => 'bg-info'];
                                else
                                    return [];
                }
            ],
            ['attribute'=>'teacher_name',
        	'label'=>'负责老师',
        	'value'=>'teacher.name',
    		],
            'score',

            //['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
