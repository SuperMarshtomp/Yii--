<?php

namespace frontend\controllers;

use Yii;
use common\models\Achievement;
use common\models\AchievementSearch;
use common\models\Student;
use common\models\StudentSearch;
use common\models\Teacher;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\ForbiddenHttpException;
use yii\filters\VerbFilter;

/**
 * AchievementController implements the CRUD actions for Achievement model.
 */
class AchievementController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Achievement models.
     * @return mixed
     */
    public function actionIndex()
    {
        if (Yii::$app->user->isGuest){
            return $this->goHome();
        }
        
        $searchModel = new AchievementSearch();
        $stuModel = new StudentSearch();
        $dataProvider = $searchModel->stusearch(Yii::$app->request->queryParams,$stuModel->getstu_id(Yii::$app->user->id));
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    
}
