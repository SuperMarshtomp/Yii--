<?php
namespace frontend\models;

use yii\base\Model;
use common\models\User;
use common\models\Student;
use phpDocumentor\Reflection\Types\Null_;

/**
 * Signup form
 */
class SignupForm extends Model
{
    public $username;
    public $email;
    public $password;
    public $student_id;
    public $student_name;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            ['username', 'trim'],
            ['username', 'required'],
            ['username', 'unique', 'targetClass' => '\common\models\User', 'message' => 'This username has already been taken.'],
            ['username', 'string', 'min' => 2, 'max' => 255],

            ['email', 'trim'],
            ['email', 'required'],
            ['email', 'email'],
            ['email', 'string', 'max' => 255],
            ['email', 'unique', 'targetClass' => '\common\models\User', 'message' => 'This email address has already been taken.'],

            ['password', 'required'],
            ['password', 'string', 'min' => 6],
            
            ['student_id','required'],
            ['student_id','test','message' => 'Invalid student_id',],
            
            ['student_name','required'],
            ['student_name','test2','message'=> ''],
        ];
    }

    public function test($object, $attributes) {
        if($student=Student::findOne($this->student_id)) {
            if ($student->userid!=null)
                $this->addError($object, '该学号已注册');
        }
        else
        {
            $this->addError($object, '无此学号');
        }
    }
    
    public function test2($object, $attributes) {
        if($student=Student::findOne($this->student_id))    
            if ($student->name!=$this->student_name)
            {
                $this->addError($object, '学号与姓名不对应');
            }
    }
    
    public function  attributeLabels()
    {
    	return [
                'username'=>'用户名',
                'email' => '邮箱',
    			'password'=>'密码',
    	        'student_id' => '学号',
    	       'student_name' =>'姓名',
    	];
    }

    /**
     * Signs user up.
     *
     * @return User|null the saved model or null if saving fails
     */
    public function signup()
    {
        if (!$this->validate()) {
            return null;
        }
        
        $user = new User();
        $user->username = $this->username;
        $user->email = $this->email;
        $user->setPassword($this->password);
        $user->generateAuthKey();
        
        return $user->save() ? $user : null;
    }
}
