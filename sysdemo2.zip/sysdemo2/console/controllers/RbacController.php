<?php
namespace console\controllers;

use Yii;
use yii\console\Controller;

class RbacController extends Controller
{
    public function actionInit()
    {
        $auth = Yii::$app->authManager;

        // 添加 "addJudge" 权限
        $addJudge = $auth->createPermission('addJudge');
        $addJudge->description = '添加评语';
        $auth->add($addJudge);

        // 添加 "updateScore" 权限
        $updateScore = $auth->createPermission('updateScore');
        $updateScore->description = '修改成绩';
        $auth->add($updateScore);

        // 添加 "deleteScore" 权限
        $deleteScore = $auth->createPermission('deleteScore');
        $deleteScore->description = '删除成绩';
        $auth->add($deleteScore);
        
        // // 添加 "approveComment" 权限
        // $approveComment = $auth->createPermission('approveComment');
        // $approveComment->description = '审核评论';
        // $auth->add($approveComment);
        
        $student = $auth->createRole('student');
        $student->description = '学生';
        $auth->add($student);

        
        // 添加 "teacher" 角色并赋予  “deletePost” 
        $teacher = $auth->createRole('teacher');
        $teacher->description = '任课老师';
        $auth->add($teacher);
        $auth->addChild($teacher, $updateScore);
        $auth->addChild($teacher, $deleteScore);
        
        // 添加 "classroomTeacher" 角色并赋予  “approveComment”
        $classroomTeacher = $auth->createRole('classroomTeacher');
        $classroomTeacher->description = '班主任';
        $auth->add($classroomTeacher);
        $auth->addChild($classroomTeacher, $updateScore);
        $auth->addChild($classroomTeacher, $addJudge);
        $auth->addChild($classroomTeacher, $deleteScore);

        // 添加 "admin" 角色并赋予所有其他角色拥有的权限
        $admin = $auth->createRole('admin');
        $classroomTeacher->description = '系统管理员';
        $auth->add($admin);
        $auth->addChild($admin, $updateScore);
        $auth->addChild($admin, $addJudge);
        $auth->addChild($admin, $deleteScore);
        
        

        // 为用户指派角色。其中 1 和 2 是由 IdentityInterface::getId() 返回的id （译者注：user表的id）
        // 通常在你的 User 模型中实现这个函数。
        $auth->assign($admin, 1);
        $auth->assign($student, 2);
        $auth->assign($teacher, 3);
        $auth->assign($classroomTeacher, 4);
    }
}