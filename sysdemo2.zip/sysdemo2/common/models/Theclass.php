<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "theclass".
 *
 * @property int $class_id
 * @property int $grade
 * @property int $teacher_id
 * @property int $num
 *
 * @property Student[] $students
 * @property Teacher $teacher
 */
class Theclass extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'theclass';
    }
    
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['class_id', 'grade', 'teacher_id', 'num'], 'required'],
            [['class_id', 'grade', 'teacher_id', 'num'], 'integer'],
            [['class_id'], 'unique'],
            [['teacher_id'], 'exist', 'skipOnError' => true, 'targetClass' => Teacher::className(), 'targetAttribute' => ['teacher_id' => 'teacher_id']],
        ];
    }
    
    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'class_id' => '班级',
            'grade' => '年级',
            'teacher_id' => '老师ID',
            'num' => '班级人数',
        ];
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStudents()
    {
        return $this->hasMany(Student::className(), ['class_id' => 'class_id']);
    }
    
    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTeacher()
    {
        return $this->hasOne(Teacher::className(), ['teacher_id' => 'teacher_id']);
    }
    
    public function addStudent() {
        $this->num+=1;
        $this->save();
    }
    
    public function delStudent() {
        $this->num-=1;
        $this->save();
    }

}
